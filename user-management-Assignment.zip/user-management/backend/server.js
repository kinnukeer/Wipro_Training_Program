const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let users = [
  { id: 1, name: "Akhila" },
  { id: 2, name: "Durga" }
];

// GET users
app.get("/users", (req, res) => {
  res.json(users);
});

// ADD user
app.post("/users", (req, res) => {
  const newUser = {
    id: users.length + 1,
    name: req.body.name
  };
  users.push(newUser);
  res.json(newUser);
});

// DELETE user
app.delete("/users/:id", (req, res) => {
  const id = parseInt(req.params.id);

  users = users.filter(user => user.id !== id);

  res.json({ message: "User deleted" });
});


app.listen(5000, () => {
  console.log("Server running on port 5000");
});


