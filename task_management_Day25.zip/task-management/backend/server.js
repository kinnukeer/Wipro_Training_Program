const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" },
});

app.use(cors());
app.use(express.json());

let tasks = [];
let users = [];

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.emit("loadTasks", tasks);
  socket.emit("usersUpdated", users);

  socket.on("registerUser", (username) => {
    users.push({ id: socket.id, username });
    io.emit("usersUpdated", users);
  });

  socket.on("addTask", (task) => {
  console.log("Task received from frontend:", task);

  const newTask = {
    id: Date.now(),
    title: task.title,
    description: task.description || "",
    deadline: task.deadline || "",
    assignee: task.assignee || "",
    status: "Pending"
  };
   if (newTask.assignee) {
  io.emit("taskAssigned", newTask);
}

  tasks.push(newTask);
  io.emit("taskUpdated", tasks);
});


  socket.on("updateTask", (updatedTask) => {
    tasks = tasks.map(task =>
      task.id === updatedTask.id
        ? { ...task, ...updatedTask }
        : task
    );

    io.emit("taskUpdated", tasks);
  });

  socket.on("deleteTask", (id) => {
    tasks = tasks.filter(task => task.id !== id);
    io.emit("taskUpdated", tasks);
  });

  socket.on("removeUser", (userId) => {
    users = users.filter(user => user.id !== userId);
    io.emit("usersUpdated", users);
  });

  socket.on("disconnect", () => {
    users = users.filter(user => user.id !== socket.id);
    io.emit("usersUpdated", users);
    console.log("User disconnected:", socket.id);
  });
});

server.listen(5000, () =>
  console.log("Server running on port 5000")
);
