import React from "react";

function TaskItem({ task, deleteTask, toggleStatus }) {
  return (
    <li>
      <strong>{task.title}</strong><br />
      Description: {task.description}<br />
      Deadline: {task.deadline}<br />
      Assigned To: {task.assignee}<br />
      Status: {task.status}<br />

      <button onClick={() => deleteTask(task.id)}>
        Delete
      </button>

      <button onClick={() => toggleStatus(task)}>
        Mark {task.status === "Pending" ? "Completed" : "Pending"}
      </button>
    </li>
  );
}

export default TaskItem;
