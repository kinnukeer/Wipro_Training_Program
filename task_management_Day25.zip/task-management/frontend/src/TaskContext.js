import React, { createContext, useState } from "react";

export const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);

  return (
    <TaskContext.Provider value={{ tasks, setTasks, users, setUsers }}>
      {children}
    </TaskContext.Provider>
  );
};
