import React, { useState, useEffect } from "react";
import io from "socket.io-client";
import TaskList from "./TaskList";
import { useContext } from "react";
import { TaskContext } from "./TaskContext";

import styled, { ThemeProvider } from "styled-components";

const socket = io("http://localhost:5000");

const lightTheme = { background: "#ffffff", color: "#000000" };
const darkTheme = { background: "#1e1e1e", color: "#ffffff" };

const Container = styled.div`
  background: ${(props) => props.theme.background};
  color: ${(props) => props.theme.color};
  min-height: 100vh;
  padding: 20px;
`;

function App() {

  // 🔹 Login States
  const [username, setUsername] = useState("");
  const [role, setRole] = useState("member");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const { tasks, setTasks, users, setUsers } = useContext(TaskContext);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [deadline, setDeadline] = useState("");
  const [assignee, setAssignee] = useState("");

  const [theme, setTheme] = useState(lightTheme);

  // 🔹 Socket Listeners
  useEffect(() => {

    socket.on("loadTasks", (data) => {
      setTasks(data);
    });

    socket.on("taskUpdated", (data) => {
      setTasks(data);
    });

    socket.on("usersUpdated", (updatedUsers) => {
      setUsers(updatedUsers);
    });

    socket.on("taskAssigned", (task) => {
  if (task.assignee === username) {
    alert(`New task assigned to you: ${task.title}`);
  }
});


    return () => {
      socket.off("loadTasks");
      socket.off("taskUpdated");
      socket.off("usersUpdated");
      socket.off("taskAssigned");

    };

  }, []);

  // 🔹 Register User
  const registerUser = () => {
    if (!username) return;
    socket.emit("registerUser", username);
    setIsLoggedIn(true);
  };

  // 🔹 Add Task
  const addTask = () => {
    if (!title) return;

    const task = {
      title,
      description,
      deadline,
      assignee
    };

    socket.emit("addTask", task);

    setTitle("");
    setDescription("");
    setDeadline("");
    setAssignee("");
  };

  // 🔹 Delete Task
  const deleteTask = (id) => {
    socket.emit("deleteTask", id);
  };

  // 🔹 Toggle Status
  const toggleStatus = (task) => {
    const updatedTask = {
      ...task,
      status: task.status === "Pending" ? "Completed" : "Pending"
    };
    socket.emit("updateTask", updatedTask);
  };

  // 🔹 Remove User (Admin Only)
  const removeUser = (userId) => {
    socket.emit("removeUser", userId);
  };

  // 🔹 LOGIN SCREEN
  if (!isLoggedIn) {
    return (
      <div style={{ padding: "20px" }}>
        <h2>Login</h2>

        <input
          placeholder="Enter Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
        >
          <option value="member">Team Member</option>
          <option value="admin">Admin</option>
        </select>

        <button onClick={registerUser}>Login</button>
      </div>
    );
  }

  // 🔹 DASHBOARD
  return (
    <ThemeProvider theme={theme}>
      <Container>

        <h1>Real-Time Task Dashboard</h1>

        <button
          onClick={() =>
            setTheme(theme === lightTheme ? darkTheme : lightTheme)
          }
        >
          Toggle Theme
        </button>

        <h3>Add Task</h3>

        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Task Title"
        />

        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Description"
        />

        <input
          type="date"
          value={deadline}
          onChange={(e) => setDeadline(e.target.value)}
        />

        <input
          value={assignee}
          onChange={(e) => setAssignee(e.target.value)}
          placeholder="Assign To"
        />

        <button onClick={addTask}>Add</button>

        <h3>Task List</h3>

        <TaskList
          tasks={tasks}
          deleteTask={deleteTask}
          toggleStatus={toggleStatus}
        />

        {role === "admin" && (
          <>
            <h3>Active Users</h3>
            <ul>
              {users.map(user => (
                <li key={user.id}>
                  {user.username}
                  <button onClick={() => removeUser(user.id)}>
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          </>
        )}

      </Container>
    </ThemeProvider>
  );
}

export default App;
