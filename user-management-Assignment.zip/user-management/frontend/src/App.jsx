import { useEffect, useState } from "react";
import UserList from "./UserList";
import UserForm from "./UserForm";
import "./App.css";


function App() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/users")
      .then(res => res.json())
      .then(data => setUsers(data));
  }, []);

  const deleteUser = (id) => {
  fetch(`http://localhost:5000/users/${id}`, {
    method: "DELETE",
  })
    .then(() => {
      setUsers(users.filter(user => user.id !== id));
    });
};


  const addUser = (user) => {
    setUsers([...users, user]);
  };

 return (
  <div className="container">
    <h1>User Management</h1>

    <UserForm addUser={addUser} />

    <UserList users={users} deleteUser={deleteUser} />
  </div>
);

}

export default App;
