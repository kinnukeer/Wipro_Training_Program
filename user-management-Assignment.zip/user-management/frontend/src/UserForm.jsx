import { useState } from "react";

function UserForm({ addUser }) {
  const [name, setName] = useState("");

  const submitHandler = (e) => {
    e.preventDefault();

    fetch("http://localhost:5000/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name })
    })
      .then(res => res.json())
      .then(data => {
        addUser(data);
        setName("");
      });
  };

  return (
    <form onSubmit={submitHandler}>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Enter name"
      />
      <button>Add User</button>
    </form>
  );
}

export default UserForm;
