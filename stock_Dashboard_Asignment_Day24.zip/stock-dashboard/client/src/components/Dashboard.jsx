import React, { Component, createRef } from "react";
import io from "socket.io-client";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement
} from "chart.js";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement);

const socket = io("http://localhost:5000");

class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stockSymbol: "",
      stockPrice: 0,
      prices: [],
      theme: "light"
    };

    this.previousSearchRef = createRef();
  }

  componentDidMount() {
    socket.on("stockUpdate", (data) => {
      this.setState((prev) => ({
        stockPrice: data.price,
        prices: [...prev.prices, data.price]
      }));
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.stockSymbol !== this.state.stockSymbol) {
      console.log("Stock symbol changed");
    }
  }

  handleChange = (e) => {
    this.setState({ stockSymbol: e.target.value });
  };

  handleSearch = () => {
    socket.emit("searchStock", this.state.stockSymbol);

    const li = document.createElement("li");
    li.textContent = this.state.stockSymbol;
    this.previousSearchRef.current.appendChild(li);
  };

  toggleTheme = () => {
    this.setState({
      theme: this.state.theme === "light" ? "dark" : "light"
    });
  };

  render() {
    const chartData = {
      labels: this.state.prices.map((_, i) => i + 1),
      datasets: [
        {
          label: "Stock Price",
          data: this.state.prices,
          borderColor: "blue",
          fill: false
        }
      ]
    };

    return (
      <div className={`container mt-4`}>
        <div className="card p-4 shadow">
          <h2 className="text-center">📈 Stock Dashboard</h2>

          <input
            className="form-control my-3"
            type="text"
            placeholder="Enter Stock Symbol"
            value={this.state.stockSymbol}
            onChange={this.handleChange}
          />

          <button className="btn btn-primary me-2" onClick={this.handleSearch}>
            Search
          </button>

          <button className="btn btn-secondary" onClick={this.toggleTheme}>
            Toggle Theme
          </button>

          <h4 className="mt-4">
            Current Price: ${this.state.stockPrice}
          </h4>

          <Line data={chartData} />

          <h5 className="mt-4">Previous Searches</h5>
          <ul ref={this.previousSearchRef}></ul>
        </div>
      </div>
    );
  }
}

export default Dashboard;
