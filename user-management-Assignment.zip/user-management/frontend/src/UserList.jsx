import React, { Component } from "react";

class UserList extends Component {
  render() {
    return (
      <ul>
        {this.props.users.map(user => (
          <li key={user.id}>
            {user.name}
            <button
              onClick={() => this.props.deleteUser(user.id)}
              style={{ marginLeft: "8px" }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    );
  }
}

export default UserList;
